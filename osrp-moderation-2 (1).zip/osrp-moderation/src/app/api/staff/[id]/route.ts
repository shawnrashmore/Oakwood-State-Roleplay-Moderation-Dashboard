import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import { getTeamForRank, canPromote, canDemote, PERMISSIONS, RANKS } from "@/lib/ranks";
import { createAuditLog } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession();
  if (!session.isLoggedIn) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const body = await req.json();
  const { action, newRank, reason } = body;

  const target = await prisma.user.findUnique({ where: { id } });
  if (!target) return NextResponse.json({ error: "Staff not found" }, { status: 404 });

  // Universal restriction: no self-modification of rank/status (Owner may override status)
  if (target.id === session.userId && action !== "reactivate" && !session.isOwner) {
    return NextResponse.json({ error: "You cannot modify your own rank or status." }, { status: 403 });
  }

  if (action === "disable") {
    if (!PERMISSIONS.manageStaff(session.rank, session.isOwner)) {
      return NextResponse.json({ error: "Permission denied" }, { status: 403 });
    }
    if (target.isOwner) return NextResponse.json({ error: "Cannot disable the Owner account" }, { status: 403 });
    await prisma.user.update({ where: { id }, data: { status: "disabled" } });
    await createAuditLog({
      actor: session,
      action: "STAFF_DISABLED",
      targetType: "User",
      targetId: id,
      targetLabel: target.username,
      previousValue: "active",
      newValue: "disabled",
    });
    return NextResponse.json({ success: true });
  }

  if (action === "reactivate") {
    if (!PERMISSIONS.manageStaff(session.rank, session.isOwner)) {
      return NextResponse.json({ error: "Permission denied" }, { status: 403 });
    }
    await prisma.user.update({ where: { id }, data: { status: "active" } });
    await createAuditLog({
      actor: session,
      action: "STAFF_REACTIVATED",
      targetType: "User",
      targetId: id,
      targetLabel: target.username,
      previousValue: "disabled",
      newValue: "active",
    });
    return NextResponse.json({ success: true });
  }

  if (action === "promote" || action === "demote") {
    if (!newRank || !reason) return NextResponse.json({ error: "New rank and reason required" }, { status: 400 });
    if (!RANKS.find((r) => r.name === newRank)) return NextResponse.json({ error: "Invalid rank" }, { status: 400 });
    if (newRank === target.rank) return NextResponse.json({ error: "Rank is already set to that value" }, { status: 400 });

    if (action === "promote") {
      if (!PERMISSIONS.promote(session.rank, session.isOwner)) {
        return NextResponse.json({ error: "You do not have permission to promote" }, { status: 403 });
      }
      if (!canPromote(session.rank, target.rank, newRank, session.isOwner)) {
        return NextResponse.json({ error: "Cannot promote to a rank equal to or higher than your own (or target is not below you)" }, { status: 403 });
      }
    } else {
      if (!PERMISSIONS.demote(session.rank, session.isOwner)) {
        return NextResponse.json({ error: "You do not have permission to demote" }, { status: 403 });
      }
      if (!canDemote(session.rank, target.rank, session.isOwner)) {
        return NextResponse.json({ error: "Cannot demote this staff member" }, { status: 403 });
      }
    }

    const previousTeam = target.team;
    const newTeam = getTeamForRank(newRank);

    await prisma.user.update({
      where: { id },
      data: { rank: newRank, team: newTeam },
    });

    if (action === "promote") {
      await prisma.promotion.create({
        data: {
          userId: id,
          previousRank: target.rank,
          newRank,
          previousTeam,
          newTeam,
          authorizedById: session.userId,
          reason,
          status: "approved",
        },
      });
      await createAuditLog({
        actor: session,
        action: "PROMOTION",
        targetType: "User",
        targetId: id,
        targetLabel: target.username,
        previousValue: target.rank,
        newValue: newRank,
        reason,
      });
    } else {
      await prisma.demotion.create({
        data: {
          userId: id,
          previousRank: target.rank,
          newRank,
          previousTeam,
          newTeam,
          authorizedById: session.userId,
          reason,
          status: "approved",
        },
      });
      await createAuditLog({
        actor: session,
        action: "DEMOTION",
        targetType: "User",
        targetId: id,
        targetLabel: target.username,
        previousValue: target.rank,
        newValue: newRank,
        reason,
      });
    }

    return NextResponse.json({ success: true });
  }

  return NextResponse.json({ error: "Invalid action" }, { status: 400 });
}
