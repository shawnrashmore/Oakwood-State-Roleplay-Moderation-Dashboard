import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import { hashPassword } from "@/lib/auth";
import { getTeamForRank, RANKS, PERMISSIONS } from "@/lib/ranks";
import { createAuditLog } from "@/lib/audit";
import { z } from "zod";

const createSchema = z.object({
  username: z.string().min(3).max(32).regex(/^[a-zA-Z0-9_]+$/),
  displayName: z.string().min(2).max(64),
  password: z.string().min(8),
  rank: z.string(),
});

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session.isLoggedIn) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  if (!PERMISSIONS.manageStaff(session.rank, session.isOwner)) {
    return NextResponse.json({ error: "You do not have permission to add staff." }, { status: 403 });
  }

  try {
    const body = await req.json();
    const data = createSchema.parse(body);

    if (!RANKS.find((r) => r.name === data.rank)) {
      return NextResponse.json({ error: "Invalid rank." }, { status: 400 });
    }

    const existing = await prisma.user.findUnique({ where: { username: data.username.toLowerCase() } });
    if (existing) {
      return NextResponse.json({ error: "Username already exists." }, { status: 409 });
    }

    const passwordHash = await hashPassword(data.password);
    const team = getTeamForRank(data.rank);

    const user = await prisma.user.create({
      data: {
        username: data.username.toLowerCase(),
        displayName: data.displayName,
        passwordHash,
        rank: data.rank,
        team,
        status: "active",
        createdById: session.userId,
      },
    });

    await createAuditLog({
      actor: session,
      action: "STAFF_CREATED",
      targetType: "User",
      targetId: user.id,
      targetLabel: user.username,
      newValue: `${user.displayName} (${user.rank})`,
      ipAddress: req.headers.get("x-forwarded-for") || undefined,
    });

    return NextResponse.json({ success: true, user: { id: user.id, username: user.username } });
  } catch (err: any) {
    if (err.name === "ZodError") {
      return NextResponse.json({ error: "Invalid input.", details: err.errors }, { status: 400 });
    }
    console.error(err);
    return NextResponse.json({ error: "Failed to create staff." }, { status: 500 });
  }
}
