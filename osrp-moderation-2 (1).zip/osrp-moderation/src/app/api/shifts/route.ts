import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import { createAuditLog } from "@/lib/audit";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session.isLoggedIn) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const action = body.action; // "start" | "end"

  if (action === "start") {
    const existing = await prisma.shift.findFirst({
      where: { userId: session.userId, status: "active" },
    });
    if (existing) {
      return NextResponse.json({ error: "You already have an active shift." }, { status: 400 });
    }

    const shift = await prisma.shift.create({
      data: {
        userId: session.userId,
        rankAtStart: session.rank,
        teamAtStart: session.team,
        startedAt: new Date(),
        status: "active",
      },
    });

    await createAuditLog({
      actor: session,
      action: "SHIFT_START",
      targetType: "Shift",
      targetId: shift.id,
      targetLabel: session.username,
    });

    return NextResponse.json({ success: true, shift });
  }

  if (action === "end") {
    const shiftId = body.shiftId;
    const shift = await prisma.shift.findUnique({ where: { id: shiftId } });
    if (!shift || shift.status !== "active") {
      return NextResponse.json({ error: "Active shift not found." }, { status: 404 });
    }
    if (shift.userId !== session.userId && !session.isOwner) {
      // Only owner or higher can force-end for now; expand as needed
      return NextResponse.json({ error: "You can only end your own shift." }, { status: 403 });
    }

    const endedAt = new Date();
    const durationMinutes = Math.round((endedAt.getTime() - shift.startedAt.getTime()) / 60000);

    const updated = await prisma.shift.update({
      where: { id: shift.id },
      data: {
        endedAt,
        durationMinutes,
        status: "completed",
      },
    });

    await createAuditLog({
      actor: session,
      action: "SHIFT_END",
      targetType: "Shift",
      targetId: shift.id,
      targetLabel: session.username,
      newValue: `${durationMinutes} minutes`,
    });

    return NextResponse.json({ success: true, shift: updated });
  }

  return NextResponse.json({ error: "Invalid action." }, { status: 400 });
}
