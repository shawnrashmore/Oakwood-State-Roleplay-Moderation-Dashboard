import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import { PERMISSIONS } from "@/lib/ranks";
import { createAuditLog } from "@/lib/audit";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session.isLoggedIn) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!PERMISSIONS.reviewQuota(session.rank, session.isOwner)) {
    return NextResponse.json({ error: "Permission denied" }, { status: 403 });
  }

  const { reviewId, action, reason } = await req.json();
  const review = await prisma.quotaReview.findUnique({ where: { id: reviewId }, include: { user: true } });
  if (!review) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (action === "exception") {
    if (!reason) return NextResponse.json({ error: "Reason required" }, { status: 400 });
    await prisma.quotaReview.update({
      where: { id: reviewId },
      data: {
        reviewStatus: "exception_granted",
        status: "exception",
        exceptionReason: reason,
        reviewedById: session.userId,
        reviewedAt: new Date(),
        notes: reason,
      },
    });
    await createAuditLog({
      actor: session,
      action: "QUOTA_EXCEPTION",
      targetType: "QuotaReview",
      targetId: reviewId,
      targetLabel: review.user.username,
      reason,
    });
  } else if (action === "review") {
    await prisma.quotaReview.update({
      where: { id: reviewId },
      data: {
        reviewStatus: "reviewed",
        reviewedById: session.userId,
        reviewedAt: new Date(),
      },
    });
    await createAuditLog({
      actor: session,
      action: "QUOTA_REVIEWED",
      targetType: "QuotaReview",
      targetId: reviewId,
      targetLabel: review.user.username,
    });
  }

  return NextResponse.json({ success: true });
}
