import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import { createAuditLog } from "@/lib/audit";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session.isLoggedIn) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json();
    const { username, robloxUserId, type, severity, reason, evidence, notes, actionTaken, duration } = body;
    if (!username || !reason || !actionTaken) {
      return NextResponse.json({ error: "Username, reason, and action are required" }, { status: 400 });
    }

    let member = await prisma.communityMember.findUnique({
      where: { username: username.trim() },
    });
    if (!member) {
      member = await prisma.communityMember.create({
        data: {
          username: username.trim(),
          robloxUserId: robloxUserId?.trim() || null,
          createdById: session.userId,
        },
      });
    }

    const infraction = await prisma.communityInfraction.create({
      data: {
        memberId: member.id,
        type: type || "Rule Violation",
        severity: severity || "Medium",
        reason,
        evidence: evidence || null,
        notes: notes || null,
        actionTaken,
        duration: duration || null,
        loggedById: session.userId,
      },
    });

    await createAuditLog({
      actor: session,
      action: "COMMUNITY_INFRACTION",
      targetType: "CommunityMember",
      targetId: member.id,
      targetLabel: member.username,
      newValue: `${actionTaken}: ${reason}`,
    });

    return NextResponse.json({ success: true, memberId: member.id, infractionId: infraction.id });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to log infraction" }, { status: 500 });
  }
}
