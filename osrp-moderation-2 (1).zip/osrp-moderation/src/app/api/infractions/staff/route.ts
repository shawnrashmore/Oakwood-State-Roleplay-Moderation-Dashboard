import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import { createAuditLog } from "@/lib/audit";

export async function GET() {
  const session = await getSession();
  if (!session.isLoggedIn) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const infractions = await prisma.staffInfraction.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      user: { select: { id: true, displayName: true, username: true } },
      loggedBy: { select: { displayName: true } },
    },
  });
  return NextResponse.json({ infractions });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session.isLoggedIn) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json();
    const { username, type, severity, reason, evidence, actionTaken, isWarning, isStrike } = body;
    if (!username || !reason) return NextResponse.json({ error: "Username and reason required" }, { status: 400 });

    const user = await prisma.user.findUnique({ where: { username: username.toLowerCase().trim() } });
    if (!user) return NextResponse.json({ error: "Staff member not found" }, { status: 404 });

    // Cannot log against yourself in a way that lets you edit own history later — still allow logging but prevent self-edit elsewhere
    if (user.id === session.userId) {
      return NextResponse.json({ error: "You cannot log an infraction against yourself" }, { status: 403 });
    }

    const infraction = await prisma.staffInfraction.create({
      data: {
        userId: user.id,
        type: type || "Other",
        severity: severity || "Medium",
        reason,
        evidence: evidence || null,
        actionTaken: actionTaken || null,
        isWarning: !!isWarning,
        isStrike: !!isStrike,
        loggedById: session.userId,
      },
    });

    await createAuditLog({
      actor: session,
      action: "STAFF_INFRACTION",
      targetType: "User",
      targetId: user.id,
      targetLabel: user.username,
      newValue: `${type}: ${reason}`,
    });

    return NextResponse.json({ success: true, id: infraction.id });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
