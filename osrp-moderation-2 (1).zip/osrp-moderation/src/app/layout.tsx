import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "OSRP Moderation — Staff Management",
  description: "Oakwood State Roleplay Moderation Staff Management System",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased min-h-screen">{children}</body>
    </html>
  );
}
