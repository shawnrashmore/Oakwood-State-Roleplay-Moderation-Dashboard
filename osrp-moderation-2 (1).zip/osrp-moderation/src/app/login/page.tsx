"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Login failed");
        setLoading(false);
        return;
      }
      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[var(--osrp-bg)] relative overflow-hidden">
      {/* Subtle forest pattern overlay */}
      <div className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, #1a5c2e 0%, transparent 50%),
                             radial-gradient(circle at 80% 20%, #166534 0%, transparent 40%)`,
        }}
      />
      <div className="w-full max-w-md relative z-10">
        <div className="card shadow-2xl border-[var(--osrp-green)]/30">
          <div className="flex flex-col items-center mb-8">
            <Image
              src="/osrp-logo.png"
              alt="Oakwood State Roleplay"
              width={180}
              height={120}
              className="mb-4 object-contain"
              priority
            />
            <h1 className="text-xl font-bold text-[var(--osrp-green-light)] tracking-wide">
              Moderation Staff Portal
            </h1>
            <p className="text-sm text-[var(--osrp-text-muted)] mt-1">
              Authorized personnel only
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="label" htmlFor="username">Username</label>
              <input
                id="username"
                type="text"
                className="input"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
                required
                autoFocus
              />
            </div>
            <div>
              <label className="label" htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                className="input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
              />
            </div>

            {error && (
              <div className="rounded-lg bg-red-950/60 border border-red-800 text-red-200 px-4 py-3 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn btn-primary w-full py-2.5"
              disabled={loading}
            >
              {loading ? "Signing in…" : "Sign In"}
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-[var(--osrp-text-muted)]">
            Oakwood State Roleplay — Internal Staff System
          </p>
        </div>
      </div>
    </div>
  );
}
