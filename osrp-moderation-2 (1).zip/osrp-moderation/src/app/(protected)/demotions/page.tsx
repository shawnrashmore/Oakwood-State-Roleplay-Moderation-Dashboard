export const dynamic = "force-dynamic";

import { prisma } from "@/lib/db";
import Link from "next/link";

export default async function DemotionsPage() {
  const demotions = await prisma.demotion.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      user: { select: { id: true, displayName: true, username: true } },
      authorizedBy: { select: { displayName: true } },
    },
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Demotion Log</h1>
      <p className="text-sm text-[var(--osrp-text-muted)]">Demotions are performed from individual staff profiles.</p>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Staff</th>
              <th>Previous</th>
              <th>New Rank</th>
              <th>Authorized By</th>
              <th>Reason</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {demotions.length === 0 ? (
              <tr><td colSpan={6} className="text-center text-[var(--osrp-text-muted)] py-8">No demotions recorded yet.</td></tr>
            ) : (
              demotions.map((d) => (
                <tr key={d.id}>
                  <td>
                    <Link href={`/staff/${d.user.id}`} className="text-[var(--osrp-green-light)] hover:underline">
                      {d.user.displayName}
                    </Link>
                  </td>
                  <td>{d.previousRank}</td>
                  <td className="font-medium">{d.newRank}</td>
                  <td>{d.authorizedBy.displayName}</td>
                  <td className="max-w-xs truncate">{d.reason}</td>
                  <td className="text-sm text-[var(--osrp-text-muted)]">
                    {new Date(d.createdAt).toLocaleString("en-US", { timeZone: "America/New_York" })}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
