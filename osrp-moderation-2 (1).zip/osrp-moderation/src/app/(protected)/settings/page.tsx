"use client";

import { useState } from "react";

export default function SettingsPage() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setMsg("");
    setError("");
    if (next !== confirm) {
      setError("New passwords do not match");
      return;
    }
    if (next.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: current, newPassword: next }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed");
      } else {
        setMsg("Password changed successfully");
        setCurrent("");
        setNext("");
        setConfirm("");
      }
    } catch {
      setError("Network error");
    }
    setLoading(false);
  }

  return (
    <div className="max-w-md space-y-6">
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Settings</h1>
      <form onSubmit={changePassword} className="card space-y-4">
        <h2 className="font-semibold">Change Password</h2>
        <div>
          <label className="label">Current Password</label>
          <input type="password" className="input" required value={current} onChange={(e) => setCurrent(e.target.value)} />
        </div>
        <div>
          <label className="label">New Password</label>
          <input type="password" className="input" required minLength={8} value={next} onChange={(e) => setNext(e.target.value)} />
        </div>
        <div>
          <label className="label">Confirm New Password</label>
          <input type="password" className="input" required value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        </div>
        {error && <p className="text-red-400 text-sm">{error}</p>}
        {msg && <p className="text-green-400 text-sm">{msg}</p>}
        <button type="submit" disabled={loading} className="btn btn-primary w-full">
          {loading ? "Saving…" : "Update Password"}
        </button>
      </form>
    </div>
  );
}
