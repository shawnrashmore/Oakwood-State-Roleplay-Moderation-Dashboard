"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

const RANKS = [
  "Founder","Co-Founder","Assistant Founder","Assistant Co-Founder",
  "Director","Deputy Director","Assistant Director","Board Of Executives",
  "Internal Affairs","Head Management","Management","Junior Management","Highranking Interm",
  "Head Administrator","Administrator","Junior Administrator","Trial Administrator",
  "Head Moderator","Senior Moderator","Moderator","Junior Moderator","Trial Moderator","Trainee Moderator",
];

export default function AddStaffPage() {
  const router = useRouter();
  const [form, setForm] = useState({ username: "", displayName: "", password: "", rank: "Trainee Moderator" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/staff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to create staff");
        setLoading(false);
        return;
      }
      router.push(`/staff/${data.user.id}`);
      router.refresh();
    } catch {
      setError("Network error");
      setLoading(false);
    }
  }

  return (
    <div className="max-w-lg space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/staff" className="text-sm text-[var(--osrp-green-bright)] hover:underline">← Staff Directory</Link>
      </div>
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Add Staff Member</h1>
      <form onSubmit={handleSubmit} className="card space-y-4">
        <div>
          <label className="label">Username</label>
          <input className="input" required minLength={3} value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="lowercase_username" />
        </div>
        <div>
          <label className="label">Display Name</label>
          <input className="input" required value={form.displayName}
            onChange={(e) => setForm({ ...form, displayName: e.target.value })} />
        </div>
        <div>
          <label className="label">Initial Password</label>
          <input className="input" type="password" required minLength={8} value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </div>
        <div>
          <label className="label">Rank</label>
          <select className="input" value={form.rank} onChange={(e) => setForm({ ...form, rank: e.target.value })}>
            {RANKS.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        {error && <div className="rounded-lg bg-red-950/60 border border-red-800 text-red-200 px-4 py-3 text-sm">{error}</div>}
        <button type="submit" disabled={loading} className="btn btn-primary w-full">{loading ? "Creating…" : "Create Staff Account"}</button>
      </form>
    </div>
  );
}
