import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { notFound } from "next/navigation";
import Link from "next/link";
import StaffActions from "@/components/StaffActions";
import { getCurrentWeekBounds, calculateHoursForUser, REQUIRED_HOURS } from "@/lib/quota";

export default async function StaffProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getSession();
  const user = await prisma.user.findUnique({
    where: { id },
    include: {
      promotionsReceived: { orderBy: { createdAt: "desc" }, take: 10, include: { authorizedBy: { select: { displayName: true } } } },
      demotionsReceived: { orderBy: { createdAt: "desc" }, take: 10, include: { authorizedBy: { select: { displayName: true } } } },
      staffInfractionsReceived: { orderBy: { createdAt: "desc" }, take: 10, include: { loggedBy: { select: { displayName: true } } } },
      notes: { orderBy: { createdAt: "desc" }, take: 10, include: { author: { select: { displayName: true } } } },
    },
  });
  if (!user) notFound();

  const { weekStart, weekEnd } = getCurrentWeekBounds();
  const weekHours = await calculateHoursForUser(user.id, weekStart, weekEnd);

  const completedShifts = await prisma.shift.findMany({
    where: { userId: user.id, status: "completed" },
    orderBy: { startedAt: "desc" },
    take: 15,
  });
  const lifetimeMinutes = completedShifts.reduce((s, sh) => s + (sh.durationMinutes || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <Link href="/staff" className="text-sm text-[var(--osrp-green-bright)] hover:underline">← Staff Directory</Link>
          <h1 className="text-2xl font-bold text-[var(--osrp-green-light)] mt-2">{user.displayName}</h1>
          <p className="text-[var(--osrp-text-muted)]">@{user.username}</p>
        </div>
        <span className={`badge ${user.status === "active" ? "badge-active" : "badge-disabled"}`}>{user.status}</span>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="card">
          <p className="text-xs text-[var(--osrp-text-muted)] uppercase">Rank</p>
          <p className="text-lg font-semibold">{user.rank}</p>
          <p className="text-sm text-[var(--osrp-text-muted)]">{user.team}</p>
        </div>
        <div className="card">
          <p className="text-xs text-[var(--osrp-text-muted)] uppercase">This Week</p>
          <p className="text-lg font-semibold">{weekHours.toFixed(2)} hrs</p>
          <p className="text-sm">{weekHours >= REQUIRED_HOURS ? <span className="text-green-400">Met quota</span> : <span className="text-amber-400">Below quota</span>}</p>
        </div>
        <div className="card">
          <p className="text-xs text-[var(--osrp-text-muted)] uppercase">Lifetime (recent)</p>
          <p className="text-lg font-semibold">{(lifetimeMinutes / 60).toFixed(1)} hrs</p>
          <p className="text-sm text-[var(--osrp-text-muted)]">Last login: {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString("en-US", { timeZone: "America/New_York" }) : "Never"}</p>
        </div>
      </div>

      <StaffActions
        userId={user.id}
        currentRank={user.rank}
        status={user.status}
        isSelf={user.id === session.userId}
        isOwner={session.isOwner}
        actorRank={session.rank}
      />

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="text-lg font-semibold mb-3 text-[var(--osrp-green-light)]">Promotion History</h2>
          {user.promotionsReceived.length === 0 ? <p className="text-sm text-[var(--osrp-text-muted)]">None</p> : (
            <ul className="space-y-2 text-sm">
              {user.promotionsReceived.map((p) => (
                <li key={p.id} className="border-b border-[var(--osrp-border)] pb-2">
                  {p.previousRank} → <strong>{p.newRank}</strong>
                  <div className="text-xs text-[var(--osrp-text-muted)]">by {p.authorizedBy.displayName} · {new Date(p.createdAt).toLocaleDateString()}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="card">
          <h2 className="text-lg font-semibold mb-3 text-[var(--osrp-green-light)]">Demotion History</h2>
          {user.demotionsReceived.length === 0 ? <p className="text-sm text-[var(--osrp-text-muted)]">None</p> : (
            <ul className="space-y-2 text-sm">
              {user.demotionsReceived.map((d) => (
                <li key={d.id} className="border-b border-[var(--osrp-border)] pb-2">
                  {d.previousRank} → <strong>{d.newRank}</strong>
                  <div className="text-xs text-[var(--osrp-text-muted)]">by {d.authorizedBy.displayName} · {new Date(d.createdAt).toLocaleDateString()}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="card">
          <h2 className="text-lg font-semibold mb-3 text-[var(--osrp-green-light)]">Staff Infractions</h2>
          {user.staffInfractionsReceived.length === 0 ? <p className="text-sm text-[var(--osrp-text-muted)]">None</p> : (
            <ul className="space-y-2 text-sm">
              {user.staffInfractionsReceived.map((i) => (
                <li key={i.id} className="border-b border-[var(--osrp-border)] pb-2">
                  <strong>{i.type}</strong> ({i.severity}) — {i.reason}
                  <div className="text-xs text-[var(--osrp-text-muted)]">by {i.loggedBy.displayName} · {new Date(i.createdAt).toLocaleDateString()}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="card">
          <h2 className="text-lg font-semibold mb-3 text-[var(--osrp-green-light)]">Recent Shifts</h2>
          {completedShifts.length === 0 ? <p className="text-sm text-[var(--osrp-text-muted)]">None</p> : (
            <ul className="space-y-1 text-sm">
              {completedShifts.slice(0, 8).map((s) => (
                <li key={s.id}>
                  {new Date(s.startedAt).toLocaleDateString()} — {(s.durationMinutes || 0) / 60} hrs
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
