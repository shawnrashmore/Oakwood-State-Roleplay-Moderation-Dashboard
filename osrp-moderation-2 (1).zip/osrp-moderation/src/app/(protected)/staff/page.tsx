export const dynamic = "force-dynamic";

import { prisma } from "@/lib/db";
import Link from "next/link";
import { getSession } from "@/lib/session";

export default async function StaffDirectoryPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; team?: string; status?: string }>;
}) {
  const params = await searchParams;
  const session = await getSession();

  const where: any = {};
  if (params.q) {
    where.OR = [
      { username: { contains: params.q } },
      { displayName: { contains: params.q } },
    ];
  }
  if (params.team) where.team = params.team;
  if (params.status) where.status = params.status;

  const staff = await prisma.user.findMany({
    where,
    orderBy: [{ team: "asc" }, { rank: "asc" }, { displayName: "asc" }],
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Staff Directory</h1>
          <p className="text-sm text-[var(--osrp-text-muted)]">{staff.length} members</p>
        </div>
        <Link href="/staff/add" className="btn btn-primary">Add Staff</Link>
      </div>

      <form className="card flex flex-col sm:flex-row gap-3">
        <input name="q" defaultValue={params.q} placeholder="Search name or username…" className="input flex-1" />
        <select name="team" defaultValue={params.team || ""} className="input w-full sm:w-48">
          <option value="">All Teams</option>
          <option>Foundership</option>
          <option>Directive Team</option>
          <option>High Ranking Team</option>
          <option>Administrator Team</option>
          <option>Moderation Team</option>
        </select>
        <select name="status" defaultValue={params.status || ""} className="input w-full sm:w-36">
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="disabled">Disabled</option>
        </select>
        <button type="submit" className="btn btn-primary">Filter</button>
      </form>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Username</th>
              <th>Rank</th>
              <th>Team</th>
              <th>Status</th>
              <th>Last Login</th>
            </tr>
          </thead>
          <tbody>
            {staff.length === 0 ? (
              <tr><td colSpan={6} className="text-center text-[var(--osrp-text-muted)] py-8">No staff found.</td></tr>
            ) : (
              staff.map((s) => (
                <tr key={s.id}>
                  <td>
                    <Link href={`/staff/${s.id}`} className="text-[var(--osrp-green-light)] hover:underline font-medium">
                      {s.displayName}
                    </Link>
                  </td>
                  <td className="text-[var(--osrp-text-muted)]">{s.username}</td>
                  <td>{s.rank}</td>
                  <td className="text-sm">{s.team}</td>
                  <td>
                    <span className={`badge ${s.status === "active" ? "badge-active" : "badge-disabled"}`}>
                      {s.status}
                    </span>
                  </td>
                  <td className="text-sm text-[var(--osrp-text-muted)]">
                    {s.lastLoginAt
                      ? new Date(s.lastLoginAt).toLocaleString("en-US", { timeZone: "America/New_York" })
                      : "—"}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
