export const dynamic = "force-dynamic";

import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import { getCurrentWeekBounds, calculateHoursForUser, REQUIRED_HOURS } from "@/lib/quota";
import Link from "next/link";

export default async function DashboardPage() {
  const session = await getSession();
  const { weekStart, weekEnd } = getCurrentWeekBounds();

  const [totalStaff, activeStaff, disabledStaff, activeShifts, pendingQuota] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { status: "active" } }),
    prisma.user.count({ where: { status: "disabled" } }),
    prisma.shift.findMany({
      where: { status: "active" },
      include: { user: { select: { displayName: true, rank: true } } },
      orderBy: { startedAt: "desc" },
    }),
    prisma.quotaReview.count({ where: { reviewStatus: "pending" } }),
  ]);

  const activeUsers = await prisma.user.findMany({ where: { status: "active" }, select: { id: true } });
  let totalWeekHours = 0;
  let metQuota = 0;
  let belowQuota = 0;
  for (const u of activeUsers) {
    const h = await calculateHoursForUser(u.id, weekStart, weekEnd);
    totalWeekHours += h;
    if (h >= REQUIRED_HOURS) metQuota++;
    else belowQuota++;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Dashboard</h1>
        <p className="text-[var(--osrp-text-muted)] text-sm mt-1">
          Welcome back, {session.displayName}. Quota week ends Sunday 11:59 PM EST.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Staff", value: totalStaff },
          { label: "Active", value: activeStaff },
          { label: "Disabled", value: disabledStaff },
          { label: "On Shift", value: activeShifts.length },
          { label: "Week Hours", value: totalWeekHours.toFixed(1) },
          { label: "Met Quota", value: metQuota },
          { label: "Below Quota", value: belowQuota },
          { label: "Pending Reviews", value: pendingQuota },
        ].map((s) => (
          <div key={s.label} className="card">
            <p className="text-xs text-[var(--osrp-text-muted)] uppercase">{s.label}</p>
            <p className="text-2xl font-bold text-[var(--osrp-green-light)] mt-1">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold mb-3 text-[var(--osrp-green-light)]">Currently On Shift</h2>
        {activeShifts.length === 0 ? (
          <p className="text-sm text-[var(--osrp-text-muted)]">No staff currently on shift.</p>
        ) : (
          <ul className="space-y-2">
            {activeShifts.map((s) => (
              <li key={s.id} className="text-sm">
                <Link href={`/staff/${s.userId}`} className="text-[var(--osrp-green-light)] hover:underline">
                  {s.user.displayName}
                </Link>{" "}
                — {s.rankAtStart} (since {new Date(s.startedAt).toLocaleString("en-US", { timeZone: "America/New_York" })} EST)
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
