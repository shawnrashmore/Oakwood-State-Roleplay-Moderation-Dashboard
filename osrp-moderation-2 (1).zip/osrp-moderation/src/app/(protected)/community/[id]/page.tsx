import { prisma } from "@/lib/db";
import { notFound } from "next/navigation";
import Link from "next/link";

export default async function CommunityMemberPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const member = await prisma.communityMember.findUnique({
    where: { id },
    include: {
      infractions: {
        orderBy: { createdAt: "desc" },
        include: { loggedBy: { select: { displayName: true } } },
      },
    },
  });
  if (!member) notFound();

  return (
    <div className="space-y-6">
      <Link href="/community" className="text-sm text-[var(--osrp-green-bright)] hover:underline">← Community</Link>
      <div>
        <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">{member.username}</h1>
        <p className="text-[var(--osrp-text-muted)]">
          Roblox ID: {member.robloxUserId || "—"} · Status: {member.status} · {member.infractions.length} infractions
        </p>
      </div>

      {member.notes && (
        <div className="card">
          <h2 className="text-sm font-semibold text-[var(--osrp-text-muted)] mb-1">Notes</h2>
          <p className="text-sm">{member.notes}</p>
        </div>
      )}

      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-[var(--osrp-green-light)]">Infraction History</h2>
          <Link href="/community/new" className="btn btn-primary text-sm">Log New</Link>
        </div>
        {member.infractions.length === 0 ? (
          <p className="text-sm text-[var(--osrp-text-muted)]">No infractions recorded.</p>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Severity</th>
                  <th>Action</th>
                  <th>Reason</th>
                  <th>Logged By</th>
                </tr>
              </thead>
              <tbody>
                {member.infractions.map((i) => (
                  <tr key={i.id}>
                    <td className="text-sm whitespace-nowrap">
                      {new Date(i.createdAt).toLocaleString("en-US", { timeZone: "America/New_York" })}
                    </td>
                    <td>{i.type}</td>
                    <td>{i.severity}</td>
                    <td className="font-medium">{i.actionTaken}{i.duration ? ` (${i.duration})` : ""}</td>
                    <td className="max-w-xs truncate">{i.reason}</td>
                    <td>{i.loggedBy.displayName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
