"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

const ACTIONS = ["Verbal Warning", "Warning", "Kick", "Temporary Ban", "Permanent Ban", "Other"];

export default function NewCommunityInfractionPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    username: "",
    robloxUserId: "",
    type: "Rule Violation",
    severity: "Medium",
    reason: "",
    evidence: "",
    notes: "",
    actionTaken: "Warning",
    duration: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/community/infractions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed");
        setLoading(false);
        return;
      }
      router.push(`/community/${data.memberId}`);
      router.refresh();
    } catch {
      setError("Network error");
      setLoading(false);
    }
  }

  return (
    <div className="max-w-xl space-y-6">
      <Link href="/community" className="text-sm text-[var(--osrp-green-bright)] hover:underline">← Community</Link>
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Log Community Infraction</h1>
      <p className="text-sm text-[var(--osrp-text-muted)]">If the member does not exist, a profile will be created automatically.</p>
      <form onSubmit={handleSubmit} className="card space-y-4">
        <div>
          <label className="label">Username *</label>
          <input className="input" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
        </div>
        <div>
          <label className="label">Roblox User ID (optional)</label>
          <input className="input" value={form.robloxUserId} onChange={(e) => setForm({ ...form, robloxUserId: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Type</label>
            <input className="input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} />
          </div>
          <div>
            <label className="label">Severity</label>
            <select className="input" value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })}>
              <option>Low</option><option>Medium</option><option>High</option><option>Critical</option>
            </select>
          </div>
        </div>
        <div>
          <label className="label">Action Taken *</label>
          <select className="input" value={form.actionTaken} onChange={(e) => setForm({ ...form, actionTaken: e.target.value })}>
            {ACTIONS.map((a) => <option key={a}>{a}</option>)}
          </select>
        </div>
        {(form.actionTaken === "Temporary Ban") && (
          <div>
            <label className="label">Duration</label>
            <input className="input" placeholder="e.g. 7 days" value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })} />
          </div>
        )}
        <div>
          <label className="label">Reason *</label>
          <textarea className="input" rows={3} required value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
        </div>
        <div>
          <label className="label">Evidence / Notes</label>
          <textarea className="input" rows={2} value={form.evidence} onChange={(e) => setForm({ ...form, evidence: e.target.value })} />
        </div>
        {error && <div className="rounded-lg bg-red-950/60 border border-red-800 text-red-200 px-4 py-3 text-sm">{error}</div>}
        <button type="submit" disabled={loading} className="btn btn-primary w-full">{loading ? "Saving…" : "Log Infraction"}</button>
      </form>
    </div>
  );
}
