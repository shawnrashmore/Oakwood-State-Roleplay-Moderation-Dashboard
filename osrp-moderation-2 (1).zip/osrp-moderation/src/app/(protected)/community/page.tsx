export const dynamic = "force-dynamic";

import { prisma } from "@/lib/db";
import Link from "next/link";
import CommunitySearch from "@/components/CommunitySearch";

export default async function CommunityPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const params = await searchParams;
  const q = params.q?.trim();

  let members: any[] = [];
  if (q) {
    members = await prisma.communityMember.findMany({
      where: {
        OR: [
          { username: { contains: q } },
          { robloxUserId: { contains: q } },
        ],
      },
      include: { _count: { select: { infractions: true } } },
      orderBy: { username: "asc" },
      take: 50,
    });
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Community Members</h1>
      <p className="text-sm text-[var(--osrp-text-muted)]">
        Search by username or Roblox user ID. Create a profile when logging the first infraction if needed.
      </p>

      <CommunitySearch initialQuery={q || ""} />

      {q && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Username</th>
                <th>Roblox ID</th>
                <th>Infractions</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {members.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center text-[var(--osrp-text-muted)] py-8">
                    No members found for “{q}”. You can create one when logging an infraction.
                  </td>
                </tr>
              ) : (
                members.map((m) => (
                  <tr key={m.id}>
                    <td className="font-medium">{m.username}</td>
                    <td className="text-[var(--osrp-text-muted)]">{m.robloxUserId || "—"}</td>
                    <td>{m._count.infractions}</td>
                    <td><span className="badge badge-active">{m.status}</span></td>
                    <td>
                      <Link href={`/community/${m.id}`} className="text-[var(--osrp-green-light)] hover:underline text-sm">
                        View
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
