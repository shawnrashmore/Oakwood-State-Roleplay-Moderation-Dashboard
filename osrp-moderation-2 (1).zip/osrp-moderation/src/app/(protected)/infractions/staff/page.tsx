"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

export default function StaffInfractionsPage() {
  const [infractions, setInfractions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    username: "",
    type: "Inactivity",
    severity: "Medium",
    reason: "",
    evidence: "",
    actionTaken: "Warning",
    isWarning: true,
    isStrike: false,
  });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    fetch("/api/infractions/staff")
      .then((r) => r.json())
      .then((d) => { setInfractions(d.infractions || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch("/api/infractions/staff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed");
        setSubmitting(false);
        return;
      }
      setShowForm(false);
      setForm({ ...form, username: "", reason: "", evidence: "" });
      // refresh list
      const r = await fetch("/api/infractions/staff");
      const d = await r.json();
      setInfractions(d.infractions || []);
    } catch {
      setError("Network error");
    }
    setSubmitting(false);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Staff Infractions</h1>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
          {showForm ? "Cancel" : "Log Infraction"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card space-y-4 max-w-xl">
          <div>
            <label className="label">Staff Username *</label>
            <input className="input" required value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Type</label>
              <select className="input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                <option>Inactivity</option>
                <option>Failure to follow staff rules</option>
                <option>Abuse of authority</option>
                <option>Unprofessional behavior</option>
                <option>Rule violations</option>
                <option>Improper moderation</option>
                <option>Failure to complete required duties</option>
                <option>Other</option>
              </select>
            </div>
            <div>
              <label className="label">Severity</label>
              <select className="input" value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })}>
                <option>Low</option><option>Medium</option><option>High</option><option>Critical</option>
              </select>
            </div>
          </div>
          <div>
            <label className="label">Action Taken</label>
            <input className="input" value={form.actionTaken} onChange={(e) => setForm({ ...form, actionTaken: e.target.value })} />
          </div>
          <div>
            <label className="label">Reason *</label>
            <textarea className="input" rows={3} required value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
          </div>
          <div>
            <label className="label">Evidence / Notes</label>
            <textarea className="input" rows={2} value={form.evidence} onChange={(e) => setForm({ ...form, evidence: e.target.value })} />
          </div>
          {error && <div className="text-red-400 text-sm">{error}</div>}
          <button type="submit" disabled={submitting} className="btn btn-primary">{submitting ? "Saving…" : "Log Infraction"}</button>
        </form>
      )}

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Staff</th>
              <th>Type</th>
              <th>Severity</th>
              <th>Action</th>
              <th>Reason</th>
              <th>Logged By</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-8 text-[var(--osrp-text-muted)]">Loading…</td></tr>
            ) : infractions.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-8 text-[var(--osrp-text-muted)]">No staff infractions recorded yet.</td></tr>
            ) : (
              infractions.map((i: any) => (
                <tr key={i.id}>
                  <td>
                    <Link href={`/staff/${i.userId}`} className="text-[var(--osrp-green-light)] hover:underline">
                      {i.user?.displayName || i.userId}
                    </Link>
                  </td>
                  <td>{i.type}</td>
                  <td>{i.severity}</td>
                  <td>{i.actionTaken}</td>
                  <td className="max-w-xs truncate">{i.reason}</td>
                  <td>{i.loggedBy?.displayName}</td>
                  <td className="text-sm whitespace-nowrap">
                    {new Date(i.createdAt).toLocaleString("en-US", { timeZone: "America/New_York" })}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
