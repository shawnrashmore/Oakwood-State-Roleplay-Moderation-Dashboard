export const dynamic = "force-dynamic";

import { prisma } from "@/lib/db";
import Link from "next/link";

export default async function PromotionsPage() {
  const promotions = await prisma.promotion.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      user: { select: { id: true, displayName: true, username: true } },
      authorizedBy: { select: { displayName: true } },
    },
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Promotion Log</h1>
      <p className="text-sm text-[var(--osrp-text-muted)]">Promotions are performed from individual staff profiles.</p>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Staff</th>
              <th>Previous</th>
              <th>New Rank</th>
              <th>Authorized By</th>
              <th>Reason</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {promotions.length === 0 ? (
              <tr><td colSpan={6} className="text-center text-[var(--osrp-text-muted)] py-8">No promotions recorded yet.</td></tr>
            ) : (
              promotions.map((p) => (
                <tr key={p.id}>
                  <td>
                    <Link href={`/staff/${p.user.id}`} className="text-[var(--osrp-green-light)] hover:underline">
                      {p.user.displayName}
                    </Link>
                  </td>
                  <td>{p.previousRank}</td>
                  <td className="font-medium">{p.newRank}</td>
                  <td>{p.authorizedBy.displayName}</td>
                  <td className="max-w-xs truncate">{p.reason}</td>
                  <td className="text-sm text-[var(--osrp-text-muted)]">
                    {new Date(p.createdAt).toLocaleString("en-US", { timeZone: "America/New_York" })}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
