export const dynamic = "force-dynamic";

import { prisma } from "@/lib/db";
import Link from "next/link";

export default async function ShiftHistoryPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string }>;
}) {
  const params = await searchParams;
  const where: any = {};
  if (params.status) where.status = params.status;
  if (params.q) {
    where.user = {
      OR: [
        { username: { contains: params.q } },
        { displayName: { contains: params.q } },
      ],
    };
  }

  const shifts = await prisma.shift.findMany({
    where,
    orderBy: { startedAt: "desc" },
    take: 100,
    include: { user: { select: { id: true, displayName: true, username: true } } },
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Shift History</h1>
      <form className="card flex flex-col sm:flex-row gap-3">
        <input name="q" defaultValue={params.q} placeholder="Staff name or username…" className="input flex-1" />
        <select name="status" defaultValue={params.status || ""} className="input w-full sm:w-40">
          <option value="">All</option>
          <option value="completed">Completed</option>
          <option value="active">Active</option>
        </select>
        <button type="submit" className="btn btn-primary">Filter</button>
      </form>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Staff</th>
              <th>Rank</th>
              <th>Started</th>
              <th>Ended</th>
              <th>Duration</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {shifts.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-8 text-[var(--osrp-text-muted)]">No shifts found.</td></tr>
            ) : (
              shifts.map((s) => (
                <tr key={s.id}>
                  <td>
                    <Link href={`/staff/${s.user.id}`} className="text-[var(--osrp-green-light)] hover:underline">
                      {s.user.displayName}
                    </Link>
                  </td>
                  <td>{s.rankAtStart}</td>
                  <td className="text-sm whitespace-nowrap">
                    {new Date(s.startedAt).toLocaleString("en-US", { timeZone: "America/New_York" })}
                  </td>
                  <td className="text-sm whitespace-nowrap">
                    {s.endedAt ? new Date(s.endedAt).toLocaleString("en-US", { timeZone: "America/New_York" }) : "—"}
                  </td>
                  <td>{s.durationMinutes != null ? `${(s.durationMinutes / 60).toFixed(2)} hrs` : "—"}</td>
                  <td>
                    <span className={`badge ${s.status === "active" ? "badge-pending" : "badge-met"}`}>{s.status}</span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
