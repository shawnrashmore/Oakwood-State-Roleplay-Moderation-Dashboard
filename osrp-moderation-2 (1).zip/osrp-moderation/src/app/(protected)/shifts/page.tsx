export const dynamic = "force-dynamic";

import { getSession } from "@/lib/session";
import { prisma } from "@/lib/db";
import ShiftControls from "@/components/ShiftControls";

export default async function ShiftsPage() {
  const session = await getSession();

  const activeShift = await prisma.shift.findFirst({
    where: { userId: session.userId, status: "active" },
  });

  const recentShifts = await prisma.shift.findMany({
    where: { userId: session.userId, status: "completed" },
    orderBy: { startedAt: "desc" },
    take: 20,
  });

  const lifetimeMinutes = recentShifts.reduce((s, sh) => s + (sh.durationMinutes || 0), 0);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Shift Tracker</h1>

      <div className="card">
        <h2 className="text-lg font-semibold mb-4">Your Current Shift</h2>
        <ShiftControls activeShift={activeShift ? {
          id: activeShift.id,
          startedAt: activeShift.startedAt.toISOString(),
        } : null} />
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Your Hours</h2>
        <p className="text-3xl font-bold text-[var(--osrp-green-light)]">
          {(lifetimeMinutes / 60).toFixed(1)} <span className="text-base font-normal text-[var(--osrp-text-muted)]">lifetime hours (recent)</span>
        </p>
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold mb-3">Recent Completed Shifts</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Started</th>
                <th>Ended</th>
                <th>Duration</th>
                <th>Rank</th>
              </tr>
            </thead>
            <tbody>
              {recentShifts.length === 0 ? (
                <tr><td colSpan={4} className="text-center text-[var(--osrp-text-muted)] py-6">No completed shifts yet.</td></tr>
              ) : (
                recentShifts.map((s) => (
                  <tr key={s.id}>
                    <td>{new Date(s.startedAt).toLocaleString("en-US", { timeZone: "America/New_York" })}</td>
                    <td>{s.endedAt ? new Date(s.endedAt).toLocaleString("en-US", { timeZone: "America/New_York" }) : "—"}</td>
                    <td>{s.durationMinutes != null ? `${(s.durationMinutes / 60).toFixed(2)} hrs` : "—"}</td>
                    <td>{s.rankAtStart}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
