export const dynamic = "force-dynamic";

import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import Sidebar from "@/components/Sidebar";
import { prisma } from "@/lib/db";

export default async function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session.isLoggedIn || !session.userId) {
    redirect("/login");
  }

  // Refresh user data from DB in case rank/status changed
  const user = await prisma.user.findUnique({ where: { id: session.userId } });
  if (!user || user.status === "disabled") {
    session.destroy();
    redirect("/login");
  }

  // Keep session in sync
  if (session.rank !== user.rank || session.team !== user.team) {
    session.rank = user.rank;
    session.team = user.team;
    session.displayName = user.displayName;
    session.isOwner = user.isOwner;
    await session.save();
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar
        user={{
          displayName: user.displayName,
          username: user.username,
          rank: user.rank,
          team: user.team,
        }}
      />
      <main className="flex-1 overflow-x-hidden">
        <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">{children}</div>
      </main>
    </div>
  );
}
