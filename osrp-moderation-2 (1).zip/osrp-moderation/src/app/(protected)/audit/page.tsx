export const dynamic = "force-dynamic";

import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { PERMISSIONS } from "@/lib/ranks";
import { redirect } from "next/navigation";

export default async function AuditPage({
  searchParams,
}: {
  searchParams: Promise<{ action?: string; q?: string }>;
}) {
  const session = await getSession();
  if (!PERMISSIONS.viewAudit(session.rank, session.isOwner)) {
    redirect("/dashboard");
  }

  const params = await searchParams;
  const where: any = {};
  if (params.action) where.action = params.action;
  if (params.q) {
    where.OR = [
      { actorUsername: { contains: params.q } },
      { targetLabel: { contains: params.q } },
      { action: { contains: params.q } },
    ];
  }

  const logs = await prisma.auditLog.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 200,
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Audit Log</h1>
      <p className="text-sm text-[var(--osrp-text-muted)]">Append-only. Ordinary staff cannot modify these records.</p>

      <form className="card flex flex-col sm:flex-row gap-3">
        <input name="q" defaultValue={params.q} placeholder="Search actor, target, action…" className="input flex-1" />
        <select name="action" defaultValue={params.action || ""} className="input w-full sm:w-48">
          <option value="">All actions</option>
          <option>LOGIN</option>
          <option>LOGOUT</option>
          <option>STAFF_CREATED</option>
          <option>STAFF_DISABLED</option>
          <option>STAFF_REACTIVATED</option>
          <option>PROMOTION</option>
          <option>DEMOTION</option>
          <option>SHIFT_START</option>
          <option>SHIFT_END</option>
          <option>STAFF_INFRACTION</option>
          <option>COMMUNITY_INFRACTION</option>
          <option>QUOTA_EXCEPTION</option>
          <option>QUOTA_REVIEWED</option>
        </select>
        <button type="submit" className="btn btn-primary">Filter</button>
      </form>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Time</th>
              <th>Actor</th>
              <th>Action</th>
              <th>Target</th>
              <th>Change</th>
              <th>Reason</th>
            </tr>
          </thead>
          <tbody>
            {logs.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-8 text-[var(--osrp-text-muted)]">No audit entries yet.</td></tr>
            ) : (
              logs.map((l) => (
                <tr key={l.id}>
                  <td className="text-sm whitespace-nowrap">
                    {new Date(l.createdAt).toLocaleString("en-US", { timeZone: "America/New_York" })}
                  </td>
                  <td>{l.actorUsername || "—"}</td>
                  <td className="font-medium text-sm">{l.action}</td>
                  <td className="text-sm">{l.targetLabel || l.targetType || "—"}</td>
                  <td className="text-sm max-w-xs truncate">
                    {l.previousValue && l.newValue ? `${l.previousValue} → ${l.newValue}` : l.newValue || "—"}
                  </td>
                  <td className="text-sm max-w-xs truncate">{l.reason || "—"}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
