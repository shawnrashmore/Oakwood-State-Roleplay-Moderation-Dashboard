export const dynamic = "force-dynamic";

import { prisma } from "@/lib/db";
import { getCurrentWeekBounds, getPreviousWeekBounds, generateQuotaReviewsForWeek } from "@/lib/quota";
import { getSession } from "@/lib/session";
import { PERMISSIONS } from "@/lib/ranks";
import Link from "next/link";
import QuotaActions from "@/components/QuotaActions";

export default async function QuotaPage() {
  const session = await getSession();
  const canReview = PERMISSIONS.reviewQuota(session.rank, session.isOwner);

  const { weekStart, weekEnd } = getPreviousWeekBounds(); // last completed week
  // Ensure reviews exist for previous week
  await generateQuotaReviewsForWeek(weekStart, weekEnd);

  const reviews = await prisma.quotaReview.findMany({
    where: { weekStart },
    include: { user: { select: { id: true, displayName: true, username: true, rank: true, team: true } } },
    orderBy: [{ status: "asc" }, { hoursWorked: "asc" }],
  });

  const met = reviews.filter((r) => r.status === "met");
  const below = reviews.filter((r) => r.status !== "met");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[var(--osrp-green-light)]">Sunday Quota Review</h1>
        <p className="text-sm text-[var(--osrp-text-muted)]">
          Week: {weekStart.toLocaleDateString("en-US", { timeZone: "America/New_York" })} –{" "}
          {weekEnd.toLocaleDateString("en-US", { timeZone: "America/New_York" })} (ends Sunday 11:59 PM EST)
        </p>
        <p className="text-sm text-[var(--osrp-text-muted)]">Required: 4 hours · Progression: Warning → Strike → Demotion → AWOL</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card"><p className="text-xs text-[var(--osrp-text-muted)]">Met Quota</p><p className="text-2xl font-bold text-green-400">{met.length}</p></div>
        <div className="card"><p className="text-xs text-[var(--osrp-text-muted)]">Below Quota</p><p className="text-2xl font-bold text-amber-400">{below.length}</p></div>
        <div className="card"><p className="text-xs text-[var(--osrp-text-muted)]">Pending Review</p><p className="text-2xl font-bold text-blue-400">{reviews.filter(r => r.reviewStatus === "pending").length}</p></div>
        <div className="card"><p className="text-xs text-[var(--osrp-text-muted)]">Exceptions</p><p className="text-2xl font-bold text-purple-400">{reviews.filter(r => r.reviewStatus === "exception_granted").length}</p></div>
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold mb-3 text-[var(--osrp-green-light)]">Below Quota / Recommended Actions</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Staff</th>
                <th>Rank</th>
                <th>Hours</th>
                <th>Status</th>
                <th>Missed #</th>
                <th>Recommended</th>
                <th>Review</th>
                {canReview && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {below.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-6 text-[var(--osrp-text-muted)]">All staff met quota this week.</td></tr>
              ) : (
                below.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <Link href={`/staff/${r.user.id}`} className="text-[var(--osrp-green-light)] hover:underline">
                        {r.user.displayName}
                      </Link>
                    </td>
                    <td className="text-sm">{r.user.rank}</td>
                    <td>{r.hoursWorked.toFixed(2)}</td>
                    <td>
                      <span className={`badge ${
                        r.status === "warning" ? "badge-warning" :
                        r.status === "strike" ? "badge-strike" :
                        r.status.includes("recommended") ? "badge-danger" : "badge-below"
                      }`}>{r.status.replace(/_/g, " ")}</span>
                    </td>
                    <td>{r.missedCount}</td>
                    <td className="text-sm">{r.recommendedAction || "—"}</td>
                    <td>
                      <span className={`badge ${r.reviewStatus === "exception_granted" ? "badge-approved" : r.reviewStatus === "reviewed" ? "badge-approved" : "badge-pending"}`}>
                        {r.reviewStatus.replace(/_/g, " ")}
                      </span>
                    </td>
                    {canReview && (
                      <td>
                        <QuotaActions reviewId={r.id} currentStatus={r.reviewStatus} />
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <h2 className="text-lg font-semibold mb-3 text-[var(--osrp-green-light)]">Met Quota</h2>
        <div className="flex flex-wrap gap-2">
          {met.map((r) => (
            <Link key={r.id} href={`/staff/${r.user.id}`} className="badge badge-met hover:opacity-80">
              {r.user.displayName} ({r.hoursWorked.toFixed(1)}h)
            </Link>
          ))}
          {met.length === 0 && <p className="text-sm text-[var(--osrp-text-muted)]">None yet.</p>}
        </div>
      </div>
    </div>
  );
}
