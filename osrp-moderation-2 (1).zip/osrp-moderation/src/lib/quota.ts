import { prisma } from "./db";
import { toZonedTime, fromZonedTime } from "date-fns-tz";
import { startOfWeek, endOfWeek, subWeeks, format } from "date-fns";

const EST = "America/New_York";
const REQUIRED_HOURS = 4;

/**
 * Week runs Monday 00:00 EST → Sunday 23:59:59 EST
 * Quota review generated after Sunday 11:59pm EST
 */
export function getCurrentWeekBounds(date = new Date()) {
  const zoned = toZonedTime(date, EST);
  // date-fns startOfWeek with weekStartsOn: 1 (Monday)
  const weekStartLocal = startOfWeek(zoned, { weekStartsOn: 1 });
  weekStartLocal.setHours(0, 0, 0, 0);
  const weekEndLocal = endOfWeek(zoned, { weekStartsOn: 1 });
  weekEndLocal.setHours(23, 59, 59, 999);

  const weekStart = fromZonedTime(weekStartLocal, EST);
  const weekEnd = fromZonedTime(weekEndLocal, EST);
  return { weekStart, weekEnd };
}

export function getPreviousWeekBounds(date = new Date()) {
  const prev = subWeeks(date, 1);
  return getCurrentWeekBounds(prev);
}

export async function calculateHoursForUser(userId: string, weekStart: Date, weekEnd: Date): Promise<number> {
  const shifts = await prisma.shift.findMany({
    where: {
      userId,
      status: "completed",
      startedAt: { gte: weekStart },
      endedAt: { lte: weekEnd },
    },
  });
  const totalMinutes = shifts.reduce((sum, s) => sum + (s.durationMinutes || 0), 0);
  return Math.round((totalMinutes / 60) * 100) / 100;
}

export async function getMissedQuotaCount(userId: string, beforeWeekStart: Date): Promise<number> {
  return prisma.quotaReview.count({
    where: {
      userId,
      weekStart: { lt: beforeWeekStart },
      status: { in: ["below", "warning", "strike", "demotion_recommended", "awol_recommended"] },
      reviewStatus: { not: "exception_granted" },
    },
  });
}

export function getRecommendedAction(missedCount: number, hours: number): { status: string; action: string | null } {
  if (hours >= REQUIRED_HOURS) {
    return { status: "met", action: null };
  }
  // missedCount is previous misses; this miss will be the (missedCount+1)th
  const thisMiss = missedCount + 1;
  if (thisMiss === 1) return { status: "warning", action: "Activity Warning" };
  if (thisMiss === 2) return { status: "strike", action: "Strike" };
  if (thisMiss === 3) return { status: "demotion_recommended", action: "Demotion Recommended" };
  return { status: "awol_recommended", action: "AWOL Termination Recommended" };
}

export async function generateQuotaReviewsForWeek(weekStart: Date, weekEnd: Date) {
  const activeStaff = await prisma.user.findMany({
    where: { status: "active" },
  });

  const results = [];
  for (const staff of activeStaff) {
    // Skip if already exists
    const existing = await prisma.quotaReview.findUnique({
      where: { userId_weekStart: { userId: staff.id, weekStart } },
    });
    if (existing) {
      results.push(existing);
      continue;
    }

    const hours = await calculateHoursForUser(staff.id, weekStart, weekEnd);
    const missedCount = await getMissedQuotaCount(staff.id, weekStart);
    const { status, action } = getRecommendedAction(missedCount, hours);

    const review = await prisma.quotaReview.create({
      data: {
        userId: staff.id,
        weekStart,
        weekEnd,
        hoursWorked: hours,
        requiredHours: REQUIRED_HOURS,
        status,
        missedCount: hours >= REQUIRED_HOURS ? missedCount : missedCount + 1,
        recommendedAction: action,
        reviewStatus: "pending",
      },
    });
    results.push(review);
  }
  return results;
}

export { REQUIRED_HOURS };
