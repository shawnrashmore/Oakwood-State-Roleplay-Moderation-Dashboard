/**
 * Oakwood State Roleplay — Exact Rank Hierarchy
 * Higher number = higher rank (Owner is special)
 */

export const RANKS = [
  // Foundership
  { name: "Founder", team: "Foundership", level: 23 },
  { name: "Co-Founder", team: "Foundership", level: 22 },
  { name: "Assistant Founder", team: "Foundership", level: 21 },
  { name: "Assistant Co-Founder", team: "Foundership", level: 20 },
  // Directive Team
  { name: "Director", team: "Directive Team", level: 19 },
  { name: "Deputy Director", team: "Directive Team", level: 18 },
  { name: "Assistant Director", team: "Directive Team", level: 17 },
  { name: "Board Of Executives", team: "Directive Team", level: 16 },
  // High Ranking Team
  { name: "Internal Affairs", team: "High Ranking Team", level: 15 },
  { name: "Head Management", team: "High Ranking Team", level: 14 },
  { name: "Management", team: "High Ranking Team", level: 13 },
  { name: "Junior Management", team: "High Ranking Team", level: 12 },
  { name: "Highranking Interm", team: "High Ranking Team", level: 11 },
  // Administrator Team
  { name: "Head Administrator", team: "Administrator Team", level: 10 },
  { name: "Administrator", team: "Administrator Team", level: 9 },
  { name: "Junior Administrator", team: "Administrator Team", level: 8 },
  { name: "Trial Administrator", team: "Administrator Team", level: 7 },
  // Moderation Team
  { name: "Head Moderator", team: "Moderation Team", level: 6 },
  { name: "Senior Moderator", team: "Moderation Team", level: 5 },
  { name: "Moderator", team: "Moderation Team", level: 4 },
  { name: "Junior Moderator", team: "Moderation Team", level: 3 },
  { name: "Trial Moderator", team: "Moderation Team", level: 2 },
  { name: "Trainee Moderator", team: "Moderation Team", level: 1 },
] as const;

export type RankName = (typeof RANKS)[number]["name"];
export type TeamName = (typeof RANKS)[number]["team"];

export const RANK_MAP = Object.fromEntries(RANKS.map((r) => [r.name, r])) as Record<
  RankName,
  (typeof RANKS)[number]
>;

export function getRankLevel(rank: string): number {
  return RANK_MAP[rank as RankName]?.level ?? 0;
}

export function getTeamForRank(rank: string): string {
  return RANK_MAP[rank as RankName]?.team ?? "Unknown";
}

export function canPromote(actorRank: string, targetCurrentRank: string, newRank: string, isOwner: boolean): boolean {
  if (isOwner) return true;
  const actorLevel = getRankLevel(actorRank);
  const newLevel = getRankLevel(newRank);
  // Must promote to a rank strictly below actor's rank
  if (newLevel >= actorLevel) return false;
  // Target's current rank must also be below actor (cannot promote peers or higher)
  const targetLevel = getRankLevel(targetCurrentRank);
  if (targetLevel >= actorLevel) return false;
  return true;
}

export function canDemote(actorRank: string, targetRank: string, isOwner: boolean): boolean {
  if (isOwner) return true;
  const actorLevel = getRankLevel(actorRank);
  const targetLevel = getRankLevel(targetRank);
  return targetLevel < actorLevel;
}

export function isFoundership(rank: string): boolean {
  return getTeamForRank(rank) === "Foundership";
}

export function isDirectiveOrHigher(rank: string): boolean {
  const team = getTeamForRank(rank);
  return team === "Foundership" || team === "Directive Team";
}

export function isHighRankingOrHigher(rank: string): boolean {
  const team = getTeamForRank(rank);
  return (
    team === "Foundership" ||
    team === "Directive Team" ||
    team === "High Ranking Team"
  );
}

/** Permission helpers */
export const PERMISSIONS = {
  manageStaff: (rank: string, isOwner: boolean) => isOwner || isFoundership(rank),
  promote: (rank: string, isOwner: boolean) =>
    isOwner || isFoundership(rank) || isDirectiveOrHigher(rank) || isHighRankingOrHigher(rank),
  demote: (rank: string, isOwner: boolean) =>
    isOwner || isFoundership(rank) || isDirectiveOrHigher(rank) || isHighRankingOrHigher(rank),
  reviewQuota: (rank: string, isOwner: boolean) => isOwner || isFoundership(rank) || isDirectiveOrHigher(rank),
  viewAudit: (rank: string, isOwner: boolean) => isOwner || isFoundership(rank),
  manageSettings: (rank: string, isOwner: boolean) => isOwner || isFoundership(rank),
  logStaffInfraction: (rank: string, isOwner: boolean) => true, // most staff can log
  logCommunityInfraction: (rank: string, isOwner: boolean) => true,
  viewAllStaff: (rank: string, isOwner: boolean) => true,
  correctRecords: (rank: string, isOwner: boolean) => isOwner || isFoundership(rank),
  approveSerious: (rank: string, isOwner: boolean) => isOwner || isFoundership(rank),
};
