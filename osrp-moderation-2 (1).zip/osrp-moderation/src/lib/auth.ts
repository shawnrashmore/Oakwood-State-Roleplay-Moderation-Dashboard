import bcrypt from "bcryptjs";
import { prisma } from "./db";
import { getSession } from "./session";
import { getTeamForRank } from "./ranks";

const SALT_ROUNDS = 12;
const MAX_ATTEMPTS_PER_IP = 10;
const WINDOW_MS = 15 * 60 * 1000; // 15 minutes

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function checkRateLimit(ip: string, username?: string): Promise<{ allowed: boolean; message?: string }> {
  const since = new Date(Date.now() - WINDOW_MS);
  const attempts = await prisma.loginAttempt.count({
    where: {
      ipAddress: ip,
      success: false,
      createdAt: { gte: since },
    },
  });
  if (attempts >= MAX_ATTEMPTS_PER_IP) {
    return { allowed: false, message: "Too many failed login attempts. Please try again later." };
  }
  if (username) {
    const userAttempts = await prisma.loginAttempt.count({
      where: {
        username,
        success: false,
        createdAt: { gte: since },
      },
    });
    if (userAttempts >= 5) {
      return { allowed: false, message: "Account temporarily locked due to failed attempts. Try again later." };
    }
  }
  return { allowed: true };
}

export async function recordLoginAttempt(ip: string, username: string | null, success: boolean) {
  await prisma.loginAttempt.create({
    data: { ipAddress: ip, username, success },
  });
}

export async function login(username: string, password: string, ip: string, userAgent?: string) {
  const rate = await checkRateLimit(ip, username);
  if (!rate.allowed) {
    await recordLoginAttempt(ip, username, false);
    return { success: false, error: rate.message };
  }

  const user = await prisma.user.findUnique({ where: { username: username.toLowerCase() } });
  if (!user || user.status === "disabled") {
    await recordLoginAttempt(ip, username, false);
    return { success: false, error: "Invalid username or password." };
  }

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) {
    await recordLoginAttempt(ip, username, false);
    return { success: false, error: "Invalid username or password." };
  }

  await recordLoginAttempt(ip, username, true);

  // Update last login
  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  // Create session
  const session = await getSession();
  session.userId = user.id;
  session.username = user.username;
  session.displayName = user.displayName;
  session.rank = user.rank;
  session.team = user.team;
  session.isOwner = user.isOwner;
  session.isLoggedIn = true;
  await session.save();

  // Audit
  await prisma.auditLog.create({
    data: {
      actorId: user.id,
      actorUsername: user.username,
      action: "LOGIN",
      targetType: "User",
      targetId: user.id,
      targetLabel: user.username,
      ipAddress: ip,
      userAgent: userAgent || null,
    },
  });

  return { success: true, user: { id: user.id, username: user.username, displayName: user.displayName, rank: user.rank } };
}

export async function logout(ip?: string) {
  const session = await getSession();
  if (session.isLoggedIn && session.userId) {
    await prisma.auditLog.create({
      data: {
        actorId: session.userId,
        actorUsername: session.username,
        action: "LOGOUT",
        targetType: "User",
        targetId: session.userId,
        targetLabel: session.username,
        ipAddress: ip || null,
      },
    });
  }
  session.destroy();
}
