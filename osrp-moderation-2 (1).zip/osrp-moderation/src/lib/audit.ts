import { prisma } from "./db";
import { SessionData } from "./session";

interface AuditParams {
  actor?: SessionData | null;
  action: string;
  targetType?: string;
  targetId?: string;
  targetLabel?: string;
  previousValue?: string | null;
  newValue?: string | null;
  reason?: string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
  metadata?: Record<string, unknown> | null;
}

export async function createAuditLog(params: AuditParams) {
  await prisma.auditLog.create({
    data: {
      actorId: params.actor?.userId || null,
      actorUsername: params.actor?.username || null,
      action: params.action,
      targetType: params.targetType || null,
      targetId: params.targetId || null,
      targetLabel: params.targetLabel || null,
      previousValue: params.previousValue ?? null,
      newValue: params.newValue ?? null,
      reason: params.reason ?? null,
      ipAddress: params.ipAddress ?? null,
      userAgent: params.userAgent ?? null,
      metadata: params.metadata ? JSON.stringify(params.metadata) : null,
    },
  });
}
