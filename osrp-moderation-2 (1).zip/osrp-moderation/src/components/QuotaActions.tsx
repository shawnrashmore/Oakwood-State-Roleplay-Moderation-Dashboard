"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function QuotaActions({ reviewId, currentStatus }: { reviewId: string; currentStatus: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function act(action: string) {
    const reason = action === "exception" ? prompt("Exception reason (required):") : null;
    if (action === "exception" && !reason) return;
    setLoading(true);
    await fetch("/api/quota", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reviewId, action, reason }),
    });
    router.refresh();
    setLoading(false);
  }

  if (currentStatus !== "pending") return <span className="text-xs text-[var(--osrp-text-muted)]">—</span>;

  return (
    <div className="flex gap-1">
      <button disabled={loading} onClick={() => act("review")} className="btn btn-secondary text-xs px-2 py-1">Mark Reviewed</button>
      <button disabled={loading} onClick={() => act("exception")} className="btn btn-primary text-xs px-2 py-1">Exception</button>
    </div>
  );
}
