"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function CommunitySearch({ initialQuery }: { initialQuery: string }) {
  const router = useRouter();
  const [q, setQ] = useState(initialQuery);

  function search(e: React.FormEvent) {
    e.preventDefault();
    if (q.trim()) router.push(`/community?q=${encodeURIComponent(q.trim())}`);
  }

  return (
    <form onSubmit={search} className="card flex flex-col sm:flex-row gap-3">
      <input
        className="input flex-1"
        placeholder="Search username or Roblox user ID…"
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />
      <button type="submit" className="btn btn-primary">Search</button>
      <a href="/community/new" className="btn btn-secondary text-center">+ New Profile / Infraction</a>
    </form>
  );
}
