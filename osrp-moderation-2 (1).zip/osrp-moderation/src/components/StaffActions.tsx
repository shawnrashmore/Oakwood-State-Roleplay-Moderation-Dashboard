"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const RANKS = [
  "Founder","Co-Founder","Assistant Founder","Assistant Co-Founder",
  "Director","Deputy Director","Assistant Director","Board Of Executives",
  "Internal Affairs","Head Management","Management","Junior Management","Highranking Interm",
  "Head Administrator","Administrator","Junior Administrator","Trial Administrator",
  "Head Moderator","Senior Moderator","Moderator","Junior Moderator","Trial Moderator","Trainee Moderator",
];

interface Props {
  userId: string;
  currentRank: string;
  status: string;
  isSelf: boolean;
  isOwner: boolean;
  actorRank: string;
}

export default function StaffActions({ userId, currentRank, status, isSelf, isOwner }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [newRank, setNewRank] = useState(currentRank);
  const [reason, setReason] = useState("");
  const [action, setAction] = useState<"promote" | "demote" | "disable" | "reactivate" | null>(null);

  async function submit() {
    if (!action) return;
    setLoading(true);
    setMsg("");
    try {
      let url = `/api/staff/${userId}`;
      let body: any = {};
      if (action === "promote" || action === "demote") {
        body = { action, newRank, reason };
      } else {
        body = { action };
      }
      const res = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        setMsg(data.error || "Failed");
      } else {
        setMsg("Success");
        setAction(null);
        setReason("");
        router.refresh();
      }
    } catch {
      setMsg("Network error");
    }
    setLoading(false);
  }

  if (isSelf && !isOwner) {
    return <div className="card text-sm text-[var(--osrp-text-muted)]">You cannot modify your own rank or status.</div>;
  }

  return (
    <div className="card space-y-4">
      <h2 className="text-lg font-semibold text-[var(--osrp-green-light)]">Actions</h2>
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-primary" onClick={() => setAction("promote")}>Promote</button>
        <button className="btn btn-secondary" onClick={() => setAction("demote")}>Demote</button>
        {status === "active" ? (
          <button className="btn btn-danger" onClick={() => setAction("disable")}>Disable Account</button>
        ) : (
          <button className="btn btn-primary" onClick={() => setAction("reactivate")}>Reactivate</button>
        )}
      </div>

      {action && (
        <div className="border border-[var(--osrp-border)] rounded-lg p-4 space-y-3">
          <p className="font-medium capitalize">{action} staff member</p>
          {(action === "promote" || action === "demote") && (
            <>
              <div>
                <label className="label">New Rank</label>
                <select className="input" value={newRank} onChange={(e) => setNewRank(e.target.value)}>
                  {RANKS.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Reason (required)</label>
                <textarea className="input" rows={2} value={reason} onChange={(e) => setReason(e.target.value)} required />
              </div>
            </>
          )}
          {msg && <p className={`text-sm ${msg === "Success" ? "text-green-400" : "text-red-400"}`}>{msg}</p>}
          <div className="flex gap-2">
            <button className="btn btn-primary" disabled={loading || ((action === "promote" || action === "demote") && !reason)} onClick={submit}>
              {loading ? "Working…" : "Confirm"}
            </button>
            <button className="btn btn-secondary" onClick={() => { setAction(null); setMsg(""); }}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}
