"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import Image from "next/image";
import { useState } from "react";
import {
  LayoutDashboard,
  Users,
  UserPlus,
  ArrowUpCircle,
  ArrowDownCircle,
  AlertTriangle,
  Shield,
  Clock,
  History,
  BarChart3,
  FileText,
  Bell,
  Settings,
  LogOut,
  Menu,
  X,
  Search,
} from "lucide-react";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/staff", label: "Staff Directory", icon: Users },
  { href: "/staff/add", label: "Add Staff", icon: UserPlus },
  { href: "/promotions", label: "Promotions", icon: ArrowUpCircle },
  { href: "/demotions", label: "Demotions", icon: ArrowDownCircle },
  { href: "/infractions/staff", label: "Staff Infractions", icon: AlertTriangle },
  { href: "/community", label: "Community Members", icon: Shield },
  { href: "/shifts", label: "Shift Tracker", icon: Clock },
  { href: "/shifts/history", label: "Shift History", icon: History },
  { href: "/quota", label: "Quota Reviews", icon: BarChart3 },
  { href: "/audit", label: "Audit Log", icon: FileText },
  { href: "/notifications", label: "Notifications", icon: Bell },
  { href: "/search", label: "Search", icon: Search },
  { href: "/settings", label: "Settings", icon: Settings },
];

interface SidebarProps {
  user: {
    displayName: string;
    username: string;
    rank: string;
    team: string;
  };
}

export default function Sidebar({ user }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  const NavContent = () => (
    <>
      <div className="flex items-center gap-3 px-4 py-5 border-b border-[var(--osrp-border)]">
        <Image src="/osrp-logo.png" alt="OSRP" width={48} height={32} className="object-contain" />
        <div className="min-w-0">
          <div className="text-sm font-bold text-[var(--osrp-green-light)] truncate">OSRP Moderation</div>
          <div className="text-xs text-[var(--osrp-text-muted)] truncate">Staff Portal</div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {navItems.map((item) => {
          const active = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className={`sidebar-link ${active ? "active" : ""}`}
            >
              <Icon size={18} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-[var(--osrp-border)] p-4">
        <div className="text-sm font-medium truncate">{user.displayName}</div>
        <div className="text-xs text-[var(--osrp-text-muted)] truncate">{user.rank}</div>
        <div className="text-xs text-[var(--osrp-green-muted)] truncate">{user.team}</div>
        <button onClick={handleLogout} className="sidebar-link mt-3 w-full text-left text-red-400 hover:text-red-300">
          <LogOut size={18} />
          <span>Sign Out</span>
        </button>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile toggle */}
      <button
        className="lg:hidden fixed top-4 left-4 z-50 btn btn-secondary p-2"
        onClick={() => setOpen(!open)}
        aria-label="Toggle menu"
      >
        {open ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Mobile overlay */}
      {open && (
        <div className="lg:hidden fixed inset-0 bg-black/60 z-40" onClick={() => setOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-40
          w-64 flex flex-col bg-[var(--osrp-bg-sidebar)] border-r border-[var(--osrp-border)]
          transform transition-transform duration-200
          ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
        `}
      >
        <NavContent />
      </aside>
    </>
  );
}
