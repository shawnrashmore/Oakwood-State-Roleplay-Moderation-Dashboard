"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

interface Props {
  activeShift: { id: string; startedAt: string } | null;
}

export default function ShiftControls({ activeShift }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function startShift() {
    setLoading(true);
    setError("");
    const res = await fetch("/api/shifts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "start" }),
    });
    const data = await res.json();
    if (!res.ok) setError(data.error || "Failed");
    else router.refresh();
    setLoading(false);
  }

  async function endShift() {
    if (!activeShift) return;
    setLoading(true);
    setError("");
    const res = await fetch("/api/shifts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "end", shiftId: activeShift.id }),
    });
    const data = await res.json();
    if (!res.ok) setError(data.error || "Failed");
    else router.refresh();
    setLoading(false);
  }

  if (activeShift) {
    const started = new Date(activeShift.startedAt);
    return (
      <div>
        <p className="text-sm text-[var(--osrp-text-muted)] mb-2">
          Started: {started.toLocaleString("en-US", { timeZone: "America/New_York" })} EST
        </p>
        <p className="text-lg font-medium text-green-400 mb-4">Shift is active</p>
        {error && <p className="text-red-400 text-sm mb-2">{error}</p>}
        <button onClick={endShift} disabled={loading} className="btn btn-danger">
          {loading ? "Ending…" : "End Shift"}
        </button>
      </div>
    );
  }

  return (
    <div>
      <p className="text-sm text-[var(--osrp-text-muted)] mb-4">You are not currently on shift.</p>
      {error && <p className="text-red-400 text-sm mb-2">{error}</p>}
      <button onClick={startShift} disabled={loading} className="btn btn-primary">
        {loading ? "Starting…" : "Start Shift"}
      </button>
    </div>
  );
}
