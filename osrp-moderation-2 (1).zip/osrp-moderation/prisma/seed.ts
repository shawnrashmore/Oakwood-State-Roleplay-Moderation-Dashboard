import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding Oakwood State Roleplay Moderation System...");

  const passwordHash = await bcrypt.hash("Ace@1214", 12);

  const owner = await prisma.user.upsert({
    where: { username: "shawnrashmore" },
    update: {},
    create: {
      username: "shawnrashmore",
      displayName: "Shawn Ashmore",
      passwordHash,
      rank: "Founder",
      team: "Foundership",
      status: "active",
      isOwner: true,
    },
  });

  console.log("Owner account ready:", owner.username);

  // Default system settings
  await prisma.systemSetting.upsert({
    where: { key: "weekly_quota_hours" },
    update: {},
    create: { key: "weekly_quota_hours", value: "4" },
  });
  await prisma.systemSetting.upsert({
    where: { key: "session_hours" },
    update: {},
    create: { key: "session_hours", value: "8" },
  });

  console.log("Seed complete. Login with username: shawnrashmore / password: Ace@1214");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
