# Oakwood State Roleplay — Moderation Staff Management System

Professional, secure, internal staff management portal for OSRP moderation team.

**No Discord integration.** Username/password authentication only. All permissions enforced server-side. Real database. No fake data.

## Features

- Secure login with bcrypt hashing, rate limiting, session management
- Full rank hierarchy (Foundership → Directive → High Ranking → Administrator → Moderation)
- Owner account (Shawn Ashmore / shawnrashmore) with full control
- Staff directory, profiles, add/disable/reactivate, rank changes
- Promotion & Demotion logs with permission validation (no self-promotion)
- Separate Staff Infraction system
- Separate Community Member profiles + Infraction system (searchable by username / Roblox ID)
- Real shift tracker (start/end, automatic duration, no manual hour entry)
- Weekly quota system (4 hours/week, ends Sunday 11:59 PM EST)
- Sunday quota review with progression: Warning → Strike → Demotion → AWOL Termination
- Append-only Audit Log
- Notifications
- Global search
- Dark forest-green theme with official OSRP logo
- Fully responsive (mobile hamburger sidebar)

## Tech Stack

- **Next.js 15** (App Router)
- **Prisma** + **SQLite** (local) / PostgreSQL (production)
- **bcryptjs** for password hashing
- **iron-session** for secure sessions
- **Tailwind CSS 4**
- **Zod** validation
- **date-fns-tz** for EST timezone handling

## Quick Start (Local)

```bash
# 1. Clone / extract the project
cd osrp-moderation

# 2. Install dependencies
npm install

# 3. Copy environment
cp .env.example .env
# Edit SESSION_SECRET to a long random string (≥32 chars)

# 4. Create database & generate client
npx prisma db push
npx prisma generate

# 5. Seed the Owner account
npm run db:seed

# 6. Start development server
npm run dev
```

Open http://localhost:3000

**Owner login:**
- Username: `shawnrashmore`
- Password: `Ace@1214`

Change the password after first login via Settings or staff profile.

## Production (PostgreSQL)

1. Set `DATABASE_URL` to your PostgreSQL connection string in `.env`
2. Change `provider = "postgresql"` in `prisma/schema.prisma`
3. Run `npx prisma migrate dev --name init` (or `db push`)
4. `npm run db:seed`
5. `npm run build && npm start`
6. Use a process manager (PM2) or Docker / Vercel / Railway / etc.
7. Ensure HTTPS, strong `SESSION_SECRET`, and firewall rules.

## Rank Hierarchy (exact)

**Foundership:** Founder, Co-Founder, Assistant Founder, Assistant Co-Founder  
**Directive Team:** Director, Deputy Director, Assistant Director, Board Of Executives  
**High Ranking Team:** Internal Affairs, Head Management, Management, Junior Management, Highranking Interm  
**Administrator Team:** Head Administrator, Administrator, Junior Administrator, Trial Administrator  
**Moderation Team:** Head Moderator, Senior Moderator, Moderator, Junior Moderator, Trial Moderator, Trainee Moderator

## Permission Rules (enforced on backend)

- No one can promote/demote/change rank of themselves
- Promotions only to ranks strictly below the authorizer’s rank (Owner override)
- Foundership can manage staff, approve serious actions, view full audit
- Quota exceptions and serious disciplinary actions require authorized review
- Staff cannot edit their own infractions or audit entries

## Quota Rules

- Required: **4 hours** of completed shifts per week
- Week: Monday 00:00 EST → Sunday 23:59:59 EST
- Progress on missed quotas:
  1. Activity Warning
  2. Strike
  3. Demotion Recommended
  4. AWOL Termination Recommended
- Automatic recommendations only; serious actions require human approval
- Exceptions require reason + reviewer recorded

## Security Notes

- Passwords never stored in plaintext; bcrypt (cost 12)
- Sessions via encrypted iron-session cookies (httpOnly, secure in prod)
- Rate limiting on login (IP + username)
- All sensitive actions write to append-only AuditLog
- Input validated; Prisma parameterized queries (SQL injection protection)
- No secrets in frontend bundles
- Backend authorization checks on every mutation

## Project Structure

```
prisma/
  schema.prisma      # Full data model
  seed.ts            # Owner + defaults
src/
  app/
    login/           # Public login
    (protected)/     # Auth-gated routes
      dashboard/
      staff/
      promotions/
      demotions/
      infractions/
      community/
      shifts/
      quota/
      audit/
      ...
    api/             # Route handlers
  components/        # UI components
  lib/
    ranks.ts         # Hierarchy + permission helpers
    auth.ts          # Login / hashing / rate limit
    session.ts
    quota.ts         # EST week bounds + calculations
    audit.ts
    db.ts
public/
  osrp-logo.png      # Official branding
```

## Testing Checklist

- [ ] Owner login works
- [ ] Create new staff (Foundership+)
- [ ] Disable / reactivate staff
- [ ] Promote / demote with rank validation
- [ ] Self-promotion rejected
- [ ] Start / end own shift; duration calculated
- [ ] Cannot end another user’s shift without permission
- [ ] Log staff infraction (cannot edit own)
- [ ] Create community member + log infraction; search works
- [ ] Weekly hours from completed shifts only
- [ ] Quota review generation & exception flow
- [ ] Audit log entries created for all actions
- [ ] Mobile sidebar collapses correctly

## License & Usage

Internal use for Oakwood State Roleplay moderation team only.  
Do not expose publicly without additional access controls.

---

**Oakwood State Roleplay — Moderation Staff Management System**  
Secure. Professional. Real records only.

---

## Free 24/7 Hosting (Recommended Paths)

This is a **Next.js** app with a database. Netlify Drop (static only) will **not** work.

### Option A — Easiest: Vercel + Neon (recommended)

1. **Database (free Postgres)**  
   - Go to https://neon.tech → Sign up → Create project  
   - Copy the connection string (looks like `postgresql://...`)

2. **Deploy frontend**  
   - Go to https://vercel.com → Sign up with GitHub  
   - Push this project to a GitHub repo  
   - Import the repo in Vercel  
   - Add Environment Variables:  
     - `DATABASE_URL` = your Neon connection string  
     - `SESSION_SECRET` = a long random string (32+ characters)  
   - In `prisma/schema.prisma` change:  
     `provider = "sqlite"` → `provider = "postgresql"`  
   - Deploy  
   - After first deploy, open Vercel → project → Settings → open the deployment logs or use the CLI:  
     `npx prisma db push` and `npm run db:seed` (or run them via Vercel’s “Build Command” / one-time script)

3. Site will be live at `https://your-project.vercel.app` 24/7 on the free tier.

### Option B — Railway (all-in-one)

1. https://railway.app → Sign up  
2. New Project → Deploy from GitHub  
3. Add a PostgreSQL plugin  
4. Set `DATABASE_URL` and `SESSION_SECRET`  
5. Change Prisma provider to `postgresql`  
6. Deploy. Free monthly credit is usually enough for light use.

### Option C — Render

1. https://render.com  
2. New Web Service from GitHub + separate PostgreSQL database  
3. Same env vars and Prisma provider change.

### Local testing first

```bash
npm install
cp .env.example .env
npx prisma db push
npm run db:seed
npm run dev
```

Login: **shawnrashmore** / **Ace@1214**

---

**Owner credentials (do not share publicly):**  
Username: `shawnrashmore`  
Password: `Ace@1214`  
Change the password after first login (Settings page).
