# Deploy to Netlify (fix for CVE + DATABASE_URL errors)

## 1. Upgrade already applied in this package

- `next` → **15.5.18** (patched for CVE-2025-55182 / React2Shell)
- `eslint-config-next` → **15.5.18**
- `react` / `react-dom` → **^19.2.1**
- `netlify.toml` uses `@netlify/plugin-nextjs` (do **not** publish `.next` manually)
- All data pages use `export const dynamic = "force-dynamic"` so the build does not need a live DB

## 2. Free PostgreSQL (required on Netlify)

SQLite **cannot** be used for production on Netlify (read-only filesystem).

1. Create a free DB at [neon.tech](https://neon.tech) (or Supabase).
2. Copy the connection string (starts with `postgresql://`).

## 3. Change Prisma to PostgreSQL

In `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"   // was "sqlite"
  url      = env("DATABASE_URL")
}
```

## 4. Netlify site settings

1. Connect the GitHub repo (or drag the project if using CLI).
2. **Build command:** leave default from `netlify.toml` (`npx prisma generate && npm run build`)
3. **Publish directory:** leave **empty** / let the Next.js plugin handle it.  
   Do **not** set publish to `.next`.
4. **Environment variables** (Site settings → Environment variables):

| Key | Value |
|-----|--------|
| `DATABASE_URL` | your Neon/Supabase `postgresql://...` string |
| `SESSION_SECRET` | long random string (32+ characters) |
| `NODE_VERSION` | `20` |

5. Deploy.

## 5. Initialize the production database (one time)

After the first successful deploy, seed the Owner account against the **production** database:

**Option A — from your computer:**

```bash
export DATABASE_URL="postgresql://...your neon url..."
npx prisma db push
npm run db:seed
```

**Option B — Netlify CLI:**

```bash
netlify env:set DATABASE_URL "postgresql://..."
# then run db push / seed locally with that URL
```

## 6. Login

- Username: `shawnrashmore`
- Password: `Ace@1214`

Change the password under **Settings** after first login.

## Common mistakes

| Mistake | Result |
|---------|--------|
| Publish path = `.next` | Broken deploy |
| No `@netlify/plugin-nextjs` | Wrong serverless packaging |
| Next.js &lt; 15.2.6 / 15.5.x patched | Netlify blocks deploy (CVE) |
| SQLite in production | DB errors / data loss |
| `DATABASE_URL` only in build, not runtime | API routes fail after deploy |

## Prefer Vercel instead?

Vercel is often simpler for Next.js. Same steps: Neon Postgres + env vars + change Prisma provider to `postgresql`.
